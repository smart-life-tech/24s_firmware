import time
import socket
import paho.mqtt.client as mqtt

BROKER = "10.208.47.228"
PORT = 1883
TOPIC = "hub/24S-S3-TEST/windows_test"


def test_tcp():
    print(f"Testing TCP connection to {BROKER}:{PORT}...")

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5)

    try:
        sock.connect((BROKER, PORT))
        print("TCP connection: SUCCESS")
        return True
    except Exception as e:
        print(f"TCP connection: FAILED: {e}")
        return False
    finally:
        sock.close()


def on_connect(client, userdata, flags, rc):
    print(f"MQTT connected, return code: {rc}")

    if rc == 0:
        client.subscribe("hub/#", qos=1)

        message = "Hello from Windows PC"

        result = client.publish(
            TOPIC,
            message,
            qos=1,
            retain=False
        )

        if result.rc == mqtt.MQTT_ERR_SUCCESS:
            print(f"Published: {TOPIC} -> {message}")
        else:
            print(f"Publish failed: {result.rc}")


def on_message(client, userdata, msg):
    payload = msg.payload.decode(errors="replace")
    print(f"RX: {msg.topic} -> {payload}")


def on_disconnect(client, userdata, rc):
    print(f"MQTT disconnected: {rc}")


def main():
    print("=" * 60)
    print("WINDOWS -> RASPBERRY PI MQTT TEST")
    print("=" * 60)
    print(f"Broker: {BROKER}:{PORT}")
    print(f"Topic : {TOPIC}")
    print()

    if not test_tcp():
        print("Cannot reach MQTT broker.")
        return

    client = mqtt.Client(
        client_id="windows-mqtt-test"
    )

    client.on_connect = on_connect
    client.on_message = on_message
    client.on_disconnect = on_disconnect

    try:
        print(f"Connecting to {BROKER}:{PORT}...")

        client.connect(
            BROKER,
            PORT,
            keepalive=60
        )

        client.loop_start()

        print("Waiting for MQTT connection...")

        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        print("\nStopping...")

    except Exception as e:
        print(f"MQTT ERROR: {e}")

    finally:
        client.loop_stop()

        try:
            client.disconnect()
        except Exception:
            pass


if __name__ == "__main__":
    main()